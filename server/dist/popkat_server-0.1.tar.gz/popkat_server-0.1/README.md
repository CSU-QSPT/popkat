# popkat_server

This package provides the server component and configuration file
for the server component of the PoPKAT application.
